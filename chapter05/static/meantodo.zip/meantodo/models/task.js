const mongoose = require('mongoose');

//task schema
const taskSchema = mongoose.Schema({
    title:{
        type: String,
        required: true
    },
    isDone: {
        type: Boolean,
        required: true
    },
    create_date: {
        type: Date,
        default: Date.now
    }
});

const Task = module.exports = mongoose.model('Task', taskSchema);

//get Tasks
module.exports.getTasks = (callback, limit) => {
    Task.find(callback).limit(limit);
}

//get a single task
module.exports.getTask = (id, callback) => {
    Task.findById(id, callback);
}

//add task
module.exports.addTask = (task, callback) => {
    Task.create(task, callback);
}

//update task
module.exports.updateTash = (id, task, options, callback) => {
    var query = {_id: id};
    var update = {
        title: task.title,
        isDone: task.isDone,
        create_date: task.create_date
    }
    Task.findOneAndUpdate(query, update, options, callback);
}
//delete task
module.exports.removeTask = (id, callback) => {
    var query = {_id: id};
    Task.remove(query, callback);
}
