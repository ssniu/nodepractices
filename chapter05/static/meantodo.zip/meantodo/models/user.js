const mongoose = require('mongoose');

//user schema
const userSchema = mongoose.Schema({
    firstname:{
        type: String,
        required: true
    },
    lastname: {
        type: String,
        required: true
    },
    create_date: {
        type: Date,
        default: Date.now
    },
    username: {
        type: String,
        required: true
    },
    password: {
        type: String,
        required: true
    }
});

const User = module.exports = mongoose.model('User', userSchema);

//get users
module.exports.getUsers = (callback, limit) => {
    User.find(callback).limit(limit);
}

//get a single user
module.exports.getUser = (id, callback) => {
    User.findById(id, callback);
}

//add user
module.exports.addUser = (user, callback) => {
    User.create(user, callback);
}

//update user
module.exports.updateUser = (id, user, options, callback) => {
    var query = {_id: id};
    var update = {
        firstname: user.firstname,
        lastname: user.lastname,
        username: user.username,
        password: user.password,
        create_date: user.create_date
    }
    User.findOneAndUpdate(query, update, options, callback);
}
//delete user
module.exports.removeUser = (id, callback) => {
    var query = {_id: id};
    User.remove(query, callback);
}
