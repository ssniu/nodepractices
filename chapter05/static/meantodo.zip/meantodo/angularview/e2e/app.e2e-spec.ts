import { AngularviewPage } from './app.po';

describe('angularview App', () => {
  let page: AngularviewPage;

  beforeEach(() => {
    page = new AngularviewPage();
  });

  it('should display welcome message', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('Welcome to app!!');
  });
});
