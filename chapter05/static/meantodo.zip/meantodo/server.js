const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');

//3 pages: index and task pages
var index = require('./routes/index');
var tasks = require('./routes/tasks');
var users = require('./routes/users');

//port number
var port = 3000;
var app = express();


//Connect to mongoose
mongoose.connect('mongodb://localhost/myusers');
var db = mongoose.connection;


//view engine
//setup the view file path
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs'); //view engine
app.engine('html', require('ejs').renderFile);

//set the static folder for angular
app.use(express.static(path.join(__dirname, 'angularview')));
//angular part connection
//app.use(express.static(__dirname + '/client'));
//app.use(bodyParser.json());

//body parser middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false}));

//set the url for index and task pages
app.use('/', index);
app.use('/api', users);
app.use('/api', tasks);

app.listen(port, function(){
    console.log("connected!");
});
