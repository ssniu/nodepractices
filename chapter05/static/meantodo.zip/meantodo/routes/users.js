const express = require('express');
const router = express.Router();

User = require('../models/user');
Task = require('../models/task');



//get all users
router.get('/users', (req, res, next) => {
    //res.send("tasks page");
    User.getUsers((err, users) => {
        if(err){
            throw err;
        }
        res.json(users);
    })
});

//create single user
router.post('/users', (req, res, next) => {
    var user = req.body;
    User.addUser((err, user) => {
        if(err){
            throw err;
        }
        res.json(user);
    })
});

//update the user
router.put('/users/:_id', (req, res, next) => {
    var user = req.body;
    var id = req.params._id;
    User.updateUser((err, user) => {
        if(err){
            throw err;
        }
        res.json(user);
    })
});

//delete the user
router.delete('/users/:_id', (req, res, next) => {

    var id = req.params._id;
    User.removeUser((err, user) => {
        if(err){
            throw err;
        }
        res.json(user);
    })
});



module.exports = router;
