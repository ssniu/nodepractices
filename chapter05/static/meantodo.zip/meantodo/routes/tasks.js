const express = require('express');
const router = express.Router();
User = require('../models/user');
Task = require('../models/task');

//get all tasks
router.get('/tasks', (req, res, next) => {
    //res.send("tasks page");
    Task.getTasks((err, tasks) => {
        if(err){
            throw err;
        }
        res.json(tasks);
    })
});

//create single tasks
router.post('/tasks', (req, res, next) => {
    var task = req.body;
    Task.addTask((err, task) => {
        if(err){
            throw err;
        }
        res.json(task);
    })
});

//update the task
router.put('/tasks/:_id', (req, res, next) => {
    var task = req.body;
    var id = req.params._id;
    Task.updateTask((err, task) => {
        if(err){
            throw err;
        }
        res.json(task);
    })
});

//delete the task
router.delete('/tasks/:_id', (req, res, next) => {

    var id = req.params._id;
    Task.removeTask((err, task) => {
        if(err){
            throw err;
        }
        res.json(task);
    })
});


module.exports = router;
